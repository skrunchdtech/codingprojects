/* -*- C++ -*- */

/***************************************
Class: CS251
Assignment Number: 4c
Honor Pledge: I pledge that I have not recieved nor given help on this assignment.
***************************************/

#if !defined (_Visitor_CPP)
#define _Visitor_CPP

#include "Visitor.h"

/// Dtor
Visitor::~Visitor ()
{
}

#endif //_Visitor_CPP
