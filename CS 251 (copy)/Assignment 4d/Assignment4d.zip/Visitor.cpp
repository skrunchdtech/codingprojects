/* -*- C++ -*- */
#if !defined (_Visitor_CPP)
#define _Visitor_CPP

#include "Visitor.h"

/// Dtor
Visitor::~Visitor ()
{
}

#endif //_Visitor_CPP
